package com.harsha.consumefarmerinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeFarmerinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumeFarmerinfoApplication.class, args);
	}

}
