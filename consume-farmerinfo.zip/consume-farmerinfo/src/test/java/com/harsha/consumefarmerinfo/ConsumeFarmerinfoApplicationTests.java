package com.harsha.consumefarmerinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumeFarmerinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
